import Onboarding from './Onboarding';

const App = () => {
	return (
		<div className="ob">
			<div className="ob-main">
				<Onboarding />
			</div>
		</div>
	);
};

export default App;
